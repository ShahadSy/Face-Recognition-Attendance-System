// ---------------- Modal Functions ----------------
function showModal() {
  const modal = document.getElementById('confirmationModal');
  modal.style.display = 'flex';
  setTimeout(() => modal.classList.add('show'), 10);
}

function hideModal() {
  const modal = document.getElementById('confirmationModal');
  modal.classList.remove('show');
  setTimeout(() => modal.style.display = 'none', 300);
}

// ---------------- Time & Status Functions ----------------
function formatTime24to12(time24) {
  const [h, m, s] = time24.split(':').map(Number);
  let hours = h, modifier = 'AM';
  if (h >= 12) { 
      modifier = 'PM'; 
      if (h > 12) hours = h - 12; 
  } else if (h === 0) {
      hours = 12;
  }
  return `${hours}:${String(m).padStart(2,'0')} ${modifier}`;
}

function getStatus(attendanceTime) {
  // work starts at 9:00 AM
  const workStart = new Date();
  workStart.setHours(9,0,0,0);

  const [time, modifier] = attendanceTime.split(' ');
  let [hours, minutes] = time.split(':').map(Number);
  if(modifier === 'PM' && hours !== 12) hours += 12;
  if(modifier === 'AM' && hours === 12) hours = 0;

  const attTime = new Date();
  attTime.setHours(hours, minutes,0,0);

  return attTime <= workStart ? 'Present' : 'Late';
}

// ---------------- End Session ----------------
function endSession() {
  fetch('/end_session', {method:'POST'})
  .then(res => res.json())
  .then(data => {
      if(data.status === 'session_ended'){
          hideModal();

          // Show placeholder when camera off
          document.getElementById('cameraFeed').style.display = 'none';
          document.getElementById('cameraPlaceholder').style.display = 'flex';

          // Disable button
          const doneButton = document.querySelector('.done-button');
          doneButton.textContent = 'Session Completed';
          doneButton.disabled = true;
          doneButton.style.opacity = '0.6';
          doneButton.style.cursor = 'not-allowed';
      }
  });
}

// ---------------- Attendance Table ----------------
function updateAttendanceTable() {
  fetch('/attendance')
  .then(res => res.json())
  .then(data => {
      const tableBody = document.getElementById('attendanceTableBody');
      tableBody.innerHTML = '';
      data.forEach(row => {
          const timeStr = formatTime24to12(row[1]);
          const statusText = getStatus(timeStr);

          const tr = document.createElement('tr');
          tr.innerHTML = `
              <td>${row[0]}</td>
              <td>${timeStr}</td>
              <td><span class="status-badge ${statusText === 'Present' ? 'status-present' : 'status-late'}">${statusText}</span></td>
          `;
          tableBody.appendChild(tr);
      });
      document.querySelector('.attendance-count').textContent = `${data.length} Present`;
  });
}

// Refresh table every 5s
setInterval(updateAttendanceTable, 5000);
updateAttendanceTable();

// ---------------- CSV Download ----------------
function downloadCSV() {
  fetch('/attendance')
  .then(res => res.json())
  .then(data => {
      let csvContent = "data:text/csv;charset=utf-8,Name,Time,Status\n";
      data.forEach(row => {
          csvContent += row.join(",") + "\n";
      });
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "attendance.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  });
}

// ---------------- Modal Close ----------------
document.getElementById('confirmationModal').addEventListener('click', e => {
  if(e.target === e.currentTarget) hideModal();
});
document.addEventListener('keydown', e => {
  if(e.key === 'Escape') hideModal();
});
